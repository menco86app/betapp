// src/App.jsx
import { Routes, Route, Navigate } from "react-router-dom";
import Home from "./pages/Home.jsx";
import MatchDetail from "./pages/MatchDetail.jsx";
import MatchAll from "./pages/MatchAll.jsx";

export default function App() {
  return (
    <div className="app-root">
      <div className="app-container">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/match/:matchKey" element={<MatchDetail />} />
          <Route path="/match/:matchKey/all" element={<MatchAll />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </div>
    </div>
  );
}
