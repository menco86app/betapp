// src/pages/MatchDetail.jsx
import { useEffect, useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { getRecommended, getMatchMeta } from "../api";

import CommentTab from "../components/match/CommentTab";
import StatsTab from "../components/match/StatsTab";
import BetsTab from "../components/match/BetsTab";
import MatchSwitcher from "../components/match/MatchSwitcher";


const CATEGORY_MAP = {
  ANCHOR: "BASE",
  CONFIDENCE: "PRUDENTE",
  VALUE: "AGGRESSIVA",
};

const CATEGORY_CLASS = {
  BASE: "base",
  PRUDENTE: "prudente",
  AGGRESSIVA: "aggressiva",
};

export default function MatchDetail() {
  const { matchKey } = useParams();
  const decodedKey = useMemo(() => decodeURIComponent(matchKey), [matchKey]);

  const [tab, setTab] = useState("comment");
  const [bets, setBets] = useState([]);
  const [matchMeta, setMatchMeta] = useState(null);
  const [loadingBets, setLoadingBets] = useState(true);
  const [errBets, setErrBets] = useState("");

  useEffect(() => {
    let alive = true;

    (async () => {
      try {
        setLoadingBets(true);
        const data = await getRecommended(decodedKey);
        if (!alive) return;

        setBets(
          Array.isArray(data)
            ? data.map(b => ({
                ...b,
                uiCategory: CATEGORY_MAP[b.category],
                uiClass: CATEGORY_CLASS[CATEGORY_MAP[b.category]],
              }))
            : []
        );
      } catch (e) {
        if (!alive) return;
        setErrBets("Errore caricamento scommesse");
      } finally {
        if (!alive) return;
        setLoadingBets(false);
      }

      try {
        const meta = await getMatchMeta(decodedKey);
        console.log("MATCH META RAW:", meta);

        if (!alive) return;
        setMatchMeta(meta);
      } catch {
        setMatchMeta(null);
      }
    })();

    return () => (alive = false);
  }, [decodedKey]);

  return (
    <div className="app-container">
      <div className="page-header">
  {/* SINISTRA */}
  <div className="header-links">
    <Link to="/" className="link-btn">← Home</Link>
  </div>

  {/* CENTRO */}
  <div className="header-center">
    <MatchSwitcher currentMatchKey={decodedKey} mode="all" />
  </div>

  {/* DESTRA (vuoto o link extra) */}
            <Link to={`/match/${encodeURIComponent(decodedKey)}/all`} className="link-btn">
            📋 Tutte le scommesse
          </Link>
  <div />
</div>

      <div className="tabs">
        <button className={`tab ${tab==="comment"?"active":""}`} onClick={()=>setTab("comment")}>📝 Commento</button>
        <button className={`tab ${tab==="stats"?"active":""}`} onClick={()=>setTab("stats")}>📈 Statistiche</button>
        <button className={`tab ${tab==="bets"?"active":""}`} onClick={()=>setTab("bets")}>✅ Scommesse</button>
      </div>

<div className="content-box">
  {tab === "comment" && <CommentTab comment={matchMeta?.comment} />}
  {tab === "stats" && <StatsTab meta={matchMeta} />}
  {tab === "bets" && (
    <>
      <div className="legend">
        <span className="badge base" /> BASE
        <span className="badge prudente" /> PRUDENTE
        <span className="badge aggressiva" /> AGGRESSIVA
      </div>
      <BetsTab bets={bets} loading={loadingBets} err={errBets} />
    </>
  )}
</div>
</div>
  );
}
