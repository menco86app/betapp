// src/pages/MatchAll.jsx
import { useEffect, useState, useMemo } from "react";
import { Link, useParams, useNavigate } from "react-router-dom";
import { getAllBets } from "../api";
import BetsTab from "../components/match/BetsTab";
import { Skeleton } from "../components/ui/Skeleton";
import Accordion from "../components/ui/Accordion";
import { getMarketGroup } from "../utils/marketGroups";
import MatchSwitcher from "../components/match/MatchSwitcher";


const CATEGORY_MAP = {
  ANCHOR: "BASE",
  CONFIDENCE: "PRUDENTE",
  VALUE: "AGGRESSIVA",
  "CHECK NECESSARIO": "CHECK NECESSARIO",
};

const CATEGORY_CLASS = {
  BASE: "base",
  PRUDENTE: "prudente",
  AGGRESSIVA: "aggressiva",
  "CHECK NECESSARIO": "check",
};

export default function MatchAll() {
  const { matchKey } = useParams();
  const decodedKey = decodeURIComponent(matchKey);
const navigate = useNavigate();

  const [bets, setBets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");

  useEffect(() => {
    let alive = true;

    (async () => {
      try {
        setLoading(true);
        setErr("");

        const data = await getAllBets(decodedKey);
        if (!alive) return;

        setBets(
          Array.isArray(data)
            ? data.map(b => {
                const rawCategory = b.family; // corretto

                const uiCategory =
                  CATEGORY_MAP[rawCategory] || "CHECK NECESSARIO";

                const uiClass =
                  CATEGORY_CLASS[uiCategory] || "check";

                return {
                  ...b,
                  uiCategory,
                  uiClass,
                };
              })
            : []
        );
      } catch {
        if (!alive) return;
        setErr("Errore caricamento scommesse");
      } finally {
        if (!alive) return;
        setLoading(false);
      }
    })();

    return () => (alive = false);
  }, [decodedKey]);

  /* ✅ RAGGRUPPAMENTO PER MACRO-CATEGORIA (QUI, NON FUORI) */
  const grouped = useMemo(() => {
    return bets.reduce((acc, b) => {
      const group = getMarketGroup(b.market);
      if (!acc[group]) acc[group] = [];
      acc[group].push(b);
      return acc;
    }, {});
  }, [bets]);

  return (
    <div className="app-container">
      {/* HEADER */}
    <div className="page-header">
  {/* SINISTRA */}
  <div className="header-links">
    <Link to="/" className="link-btn">← Home</Link>
    
  </div>

  {/* CENTRO */}
  <div className="header-center">
    <MatchSwitcher currentMatchKey={decodedKey} mode="all" />

  </div>

  {/* DESTRA (vuoto o link extra) */}
{/* DESTRA */}
<div className="header-right">
  <button
    className="link-btn subtle"
    onClick={() => navigate(`/match/${encodeURIComponent(decodedKey)}`)}
  >
    ← Dettaglio match
  </button>
</div>
</div>

      {/* CONTENT */}
      <div className="content-box">
        {loading && (
          <div className="list">
            {[1, 2, 3].map(i => (
              <div key={i} className="card">
                <Skeleton width="60%" />
                <Skeleton width="40%" />
                <Skeleton width="30%" />
              </div>
            ))}
          </div>
        )}

        {err && <div className="error-box">❌ {err}</div>}

        {!loading && !err && (
          <>
            {/* LEGENDA */}
            <div className="legend">
              <span className="badge base" /> BASE
              <span className="badge prudente" /> PRUDENTE
              <span className="badge aggressiva" /> AGGRESSIVA
              <span className="badge check" /> CHECK NECESSARIO
            </div>

            {/* 🔽 ACCORDION PER MACRO-CATEGORIA */}
            {Object.entries(grouped).map(([groupName, groupBets]) => (
              <Accordion
                key={groupName}
                title={`${groupName} (${groupBets.length})`}
              >
                <BetsTab bets={groupBets} loading={false} err="" />
              </Accordion>
            ))}
          </>
        )}
      </div>
    </div>
  );
}
