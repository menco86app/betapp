// src/components/match/BetsTab.jsx
import { Skeleton } from "../ui/Skeleton";

export default function BetsTab({ bets, loading, err }) {
  if (loading) {
    return (
      <div className="list">
        {[1,2,3].map(i=>(
          <div key={i} className="card">
            <Skeleton />
            <Skeleton width="50%" />
          </div>
        ))}
      </div>
    );
  }

  if (err) return <div className="error-box">❌ {err}</div>;
  if (!bets || bets.length === 0) return <div>Nessuna scommessa.</div>;

  return (
    <div className="list">
      {bets.map(b => (
        <div key={b.id} className="card">
          <div className="bet-header">
            <strong>{b.market}</strong>
            <span className={`badge ${b.uiClass}`} />
          </div>
          <div className="bet-info">
            Quota <b>{b.odds}</b> · Prob <b>{(b.prob*100).toFixed(1)}%</b>
          </div>
          <div className="bet-ev">EV <b>{Number(b.ev).toFixed(3)}</b></div>
        </div>
      ))}
    </div>
  );
}
