// src/components/match/CommentTab.jsx
import { Skeleton } from "../ui/Skeleton";

export default function CommentTab({ comment }) {
  return (
    <div className="card">
      <b>📝 Commento partita</b>
      {!comment ? (
        <>
          <Skeleton />
          <Skeleton />
          <Skeleton width="70%" />
        </>
      ) : (
        <div className="comment-text">{comment}</div>
      )}
    </div>
  );
}
