// src/App.jsx
import { Routes, Route, Navigate } from "react-router-dom";
import Home from "./pages/Home.jsx";
import Prehome from "./pages/Prehome.jsx";
import MatchDetail from "./pages/MatchDetail.jsx";
import MatchAll from "./pages/MatchAll.jsx";
import Login from "./pages/Login.jsx";

export default function App() {
  return (
    <div className="app-root">
<Routes>
  <Route path="/" element={<Prehome />} />
  <Route path="/home" element={<Home />} />
  <Route path="/login" element={<Login />} />
  <Route path="/match/:matchKey" element={<MatchDetail />} />
  <Route path="/match/:matchKey/all" element={<MatchAll />} />
</Routes>
    </div>
  );
}
