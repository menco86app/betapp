export default function MiniSchedina({ schedina }) {
  const quotaTotale = schedina.reduce(
    (acc, b) => acc * Number(b.odds || 1),
    1
  );

  return (
    <div className="card mini-schedina">
      <h3>🧾 Schedina</h3>

      <div className="mini-count">
        ☑ {schedina.length} eventi
      </div>

      <div className="mini-quota">
        Quota totale <b>{quotaTotale.toFixed(2)}</b>
      </div>

      <div className="mini-bonus">
        Bonus <b>+5%</b>
      </div>

      <button className="btn-primary full">
        Vai alla schedina
      </button>
    </div>
  );
}
